@echo off
setlocal
set "DLL=%~dp0a3dapi.dll"
if not exist "%DLL%" (
    echo a3dapi.dll is not in the folder of this script.
    pause
    exit /b 1
)
set "REGSVR32=%SystemRoot%\System32\regsvr32.exe"
if exist "%SystemRoot%\SysWOW64\regsvr32.exe" set "REGSVR32=%SystemRoot%\SysWOW64\regsvr32.exe"
"%REGSVR32%" /u "%DLL%"
